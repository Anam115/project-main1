<?php include('../includes/auth.php'); ?>
<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>

<div class="p-6">
  <h1 class="text-2xl font-bold">Welcome to Admin Dashboard</h1>
  <p>You are logged in as <strong><?= $_SESSION['admin_username']; ?></strong>.</p>
</div>

<?php include('footer.php'); ?>
