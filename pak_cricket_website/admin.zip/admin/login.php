<?php
session_start();
include('../db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE username='$username' AND role='admin' LIMIT 1");
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin['username'];
        header("Location: index.php");
    } else {
        $error = "Invalid credentials!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
  <form method="POST" class="bg-white p-8 shadow-md rounded w-96">
    <h2 class="text-2xl font-bold mb-4">Admin Login</h2>
    <?php if (isset($error)) echo "<p class='text-red-500'>$error</p>"; ?>
    <input name="username" type="text" placeholder="Username" required class="w-full mb-4 px-4 py-2 border rounded" />
    <input name="password" type="password" placeholder="Password" required class="w-full mb-4 px-4 py-2 border rounded" />
    <button type="submit" class="bg-green-600 text-white w-full py-2 rounded">Login</button>
  </form>
</body>
</html>
